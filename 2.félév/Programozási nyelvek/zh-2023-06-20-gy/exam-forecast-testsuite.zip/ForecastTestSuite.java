import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({
    AdvancedForecasterStructureTest.class,
    DynamicForecasterStructureTest.class,
    ForecasterStructureTest.class,
    IndexedWeatherDataStructureTest.class,
    SimpleForecasterStructureTest.class,
    WeatherDataStructureTest.class,
    WeatherTypeStructureTest.class
})
public class ForecastTestSuite {

}
