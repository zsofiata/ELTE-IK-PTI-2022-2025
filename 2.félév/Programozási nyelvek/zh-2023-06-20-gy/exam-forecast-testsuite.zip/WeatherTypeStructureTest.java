import static check.CheckThat.Condition.*;
import org.junit.jupiter.api.*;
import check.CheckThat;

public class WeatherTypeStructureTest {
    @Test
    public void testEnum() {
        CheckThat.theEnum("weather.data.WeatherType")
            .thatIs(FULLY_IMPLEMENTED, INSTANCE_LEVEL, VISIBLE_TO_ALL)
            .hasEnumElements("SUNNY", "CLOUDY", "RAINY");
    }
}

