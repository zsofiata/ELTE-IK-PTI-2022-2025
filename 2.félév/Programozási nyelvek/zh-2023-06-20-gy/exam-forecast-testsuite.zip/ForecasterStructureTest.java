import static check.CheckThat.*;
import static check.CheckThat.Condition.*;
import org.junit.jupiter.api.*;
import check.CheckThat;

public class ForecasterStructureTest {
    @BeforeAll
    public static void init() {
        CheckThat.theInterface("weather.forecast.Forecaster")
            .thatIs(VISIBLE_TO_ALL);
    }

    @Test
    public void methodForecast() {
        it.hasMethod("forecast", withParams("array of weather.data.WeatherData"))
            .thatIs(NOT_IMPLEMENTED, INSTANCE_LEVEL, VISIBLE_TO_ALL)
            .thatReturns("weather.data.WeatherData");
    }
}

