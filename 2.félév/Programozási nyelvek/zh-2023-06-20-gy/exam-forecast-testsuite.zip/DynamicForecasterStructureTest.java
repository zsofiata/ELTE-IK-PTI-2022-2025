import static check.CheckThat.*;
import static check.CheckThat.Condition.*;
import org.junit.jupiter.api.*;
import check.CheckThat;

public class DynamicForecasterStructureTest {
    @BeforeAll
    public static void init() {
        CheckThat.theClass("weather.forecast.DynamicForecaster")
            .thatIs(FULLY_IMPLEMENTED, INSTANCE_LEVEL, VISIBLE_TO_ALL);
    }

    @Test
    public void fieldData() {
        it.hasField("data", ofType("ArrayList"))
            .thatIs(INSTANCE_LEVEL, MODIFIABLE, VISIBLE_TO_NONE)
            .thatHasNo(GETTER, SETTER);
    }

    @Test
    public void fieldForecaster() {
        it.hasField("forecaster", ofType("Forecaster"))
            .thatIs(INSTANCE_LEVEL, MODIFIABLE, VISIBLE_TO_NONE)
            .thatHasNo(GETTER, SETTER);
    }

    @Test
    public void constructor() {
        it.hasConstructor(withArgs("Forecaster"))
            .thatIs(VISIBLE_TO_ALL);
    }

    @Test
    public void methodNextDayForecast() {
        it.hasMethod("nextDayForecast", withNoParams())
            .thatIs(FULLY_IMPLEMENTED, INSTANCE_LEVEL, VISIBLE_TO_ALL)
            .thatReturns("weather.data.WeatherData");
    }

    @Test
    public void methodRecordDailyData() {
        it.hasMethod("recordDailyData", withParams("int", "weather.data.WeatherType"))
            .thatIs(FULLY_IMPLEMENTED, INSTANCE_LEVEL, VISIBLE_TO_ALL)
            .thatReturnsNothing();
    }

    @Test
    public void methodRecordDailyData2() {
        it.hasMethod("recordDailyData", withParams("weather.data.WeatherData"))
            .thatIs(FULLY_IMPLEMENTED, INSTANCE_LEVEL, VISIBLE_TO_ALL)
            .thatReturnsNothing();
    }
}

