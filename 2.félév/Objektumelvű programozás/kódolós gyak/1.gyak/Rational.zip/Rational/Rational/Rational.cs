﻿using System;

namespace Rational
{
    class Rational
    {
        public class NullDenominator : Exception { };
        public class NullDivision : Exception { };

        private readonly int n;
        private readonly int d;
        public Rational(int u = 0, int v = 1) 
        { 
            if (v == 0) throw new NullDenominator();
            n = u; d = v;  
        }
        public static Rational operator + (Rational a, Rational b)
        {
            return new Rational(a.n * b.d + a.d * b.n, a.d * b.d);
        }
        public static Rational operator - (Rational a, Rational b)
        {
            return new Rational(a.n * b.d - a.d * b.n, a.d * b.d);
        }
        public static Rational operator * (Rational a, Rational b)
        {
            return new Rational(a.n * b.n, a.d * b.d);
        }
        public static Rational operator / (Rational a, Rational b)
        {
            if (0 == b.n) throw new NullDivision();
            return new Rational(a.n * b.d, a.d * b.n);
        }
        public override string ToString() 
        {
            return "(" + n.ToString() + "," + d.ToString() + ")";
        }
    }
}
