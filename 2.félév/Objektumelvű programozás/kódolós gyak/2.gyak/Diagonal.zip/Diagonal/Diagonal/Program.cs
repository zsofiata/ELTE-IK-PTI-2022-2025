﻿using System;
using System.Collections.Generic;

namespace Diagonal
{
    //class of menu for diagonal matrix
    class Menu
    {
        private readonly Diag[] matrix = new Diag[2];

        public Menu()
        {
            matrix[0] = new Diag(3);
            matrix[1] = new Diag(3);
        }

        public void Run()
        {
            int n;
            do
            {
                MenuWrite();

                n = int.Parse(Console.ReadLine());
                switch (n)
                {
                    case 1:
                        GetElement(0);
                        break;
                    case 2:
                        GetElement(1);
                        break;
                    case 3:
                        SetElement(0);
                        break;
                    case 4:
                        SetElement(1);
                        break;
                    case 5:
                        WriteMatrix(0);
                        break;
                    case 6:
                        WriteMatrix(1);
                        break;
                    case 7:
                        Sum();
                        break;
                    case 8:
                        Mul();
                        break;
                }
            } while (n != 0);

        }
        static private void MenuWrite()
        {
            Console.WriteLine( "\n\n 0. - Quit" );
            Console.WriteLine(" 1. - Get an element of the matrix A" );
            Console.WriteLine(" 2. - Get an element of the matrix B" );
            Console.WriteLine(" 3. - Overwrite an element of the matrix A" );
            Console.WriteLine(" 4. - Overwrite an element of the matrix B" );
            Console.WriteLine(" 5. - Write matrix A" );
            Console.WriteLine(" 6. - Write matrix B" );
            Console.WriteLine(" 7. - Add matrices" );
            Console.WriteLine(" 8. - Multiply matrices" );
        }
        private void GetElement(int x)
        {
            Console.WriteLine("Give the index of the row: ");
            int i = int.Parse(Console.ReadLine());
            Console.WriteLine("Give the index of the column: ");
            int j = int.Parse(Console.ReadLine());
            try
            {
                Console.WriteLine("a[{0},{1}]={2}", i, j, matrix[x][i-1, j-1]);
            }
            catch(IndexOutOfRangeException)
            {
                Console.WriteLine("Rossz indexek!");
            }
        }
        private void SetElement(int x)
        {
            Console.WriteLine("Give the index of the row: ");
            int i = int.Parse(Console.ReadLine());
            Console.WriteLine("Give the index of the column: ");
            int j = int.Parse(Console.ReadLine());
            Console.WriteLine("Give the value: ");
            int e = int.Parse(Console.ReadLine());
            try
            {
                matrix[x][i-1, j-1] = e;
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Rossz indexek!");
            }
            catch (Diag.ReferenceToNullPartException)
            {
                Console.WriteLine("Csak a főátló elemeit lehet felülírni");
            }
        }
        private void WriteMatrix(int x)
        {
            Console.Write(matrix[x].ToString());
        }
        private void Sum()
        {
            try
            {
                Console.Write((matrix[0]+ matrix[1]).ToString());
            }
            catch(Diag.DifferentSizeException)
            {
                Console.Write("Különböző méretű mátrixokat nem lehet összeadni!");
            }
        }
        private void Mul()
        {
            try
            {
                Console.Write((matrix[0] * matrix[1]).ToString());
            }
            catch(Diag.DifferentSizeException)
            {
                Console.Write("Különböző méretű mátrixokat nem lehet összeszorozni!");
            }
        }
    };
    class Program
    {
        static void Main()
        {
            Menu m = new ();
            m.Run();
        }
    }
}
