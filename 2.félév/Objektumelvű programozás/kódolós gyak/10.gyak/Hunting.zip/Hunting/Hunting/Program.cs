﻿using System;
using TextFile;

namespace Hunting
{
    class Program
    {
        static void Main()
        {
            try
            {
                Hunter hunter = new ("Zsolti", 63);
                Read(hunter, "input.txt");

                Console.WriteLine($"Number of the male lions: {hunter.CountMaleLions()}");

                if (hunter.MaxHornWeigthRate(out double rate))
                {
                    Console.WriteLine($"The most horn-weigth rate among the rhinos: {rate:f3}");
                }
                else
                {
                    Console.WriteLine("There are no rhinos");
                }

                if (hunter.SearchEqualTusks())
                {
                    Console.WriteLine("There exists an elephant with same length tusks.");
                }
                else
                {
                    Console.WriteLine("There is no elephant with same length tusks.");
                }
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("Wrong file name");
            }
        }

        static void Read(Hunter h, string fname)
        {
            TextFileReader reader = new (fname);

            string place, date, species, gender;
            double weight, lefttusk, righttusk, horn;
            Animal animal = null;

            char[] separators = new char[] { ' ', '\t' };
            while (reader.ReadLine(out string line))
            {
                string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                place = tokens[0];
                date = tokens[1];
                species = tokens[2];
                weight = int.Parse(tokens[3]);
                gender = tokens[4];

                switch (species)
                {
                    case "lion":    
                        animal = new Lion(weight, gender == "male"); 
                        break;
                    case "rhino":   
                        horn = int.Parse(tokens[5]);
                        animal = new Rhino(weight, horn, gender == "male"); 
                        break;
                    case "elephant":
                        lefttusk = int.Parse(tokens[5]);
                        righttusk = int.Parse(tokens[6]);
                        animal = new Elephant(weight, lefttusk, righttusk, gender == "male");
                        break;
                }

                h.Shot(animal, place, date);
            }
        }
    }
}
