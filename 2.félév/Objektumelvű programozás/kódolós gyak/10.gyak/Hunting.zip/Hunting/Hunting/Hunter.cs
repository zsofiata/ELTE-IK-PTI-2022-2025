﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hunting
{
    class Hunter
    {
        public readonly string name; 
        public int Age { get; }
        public List<Trophy> Trophies { get; } = new List<Trophy>();

        public Hunter(string name, int age) { this.name = name; Age = age; }

        public void Shot(Animal animal, string place, string date)
        {
            Trophies.Add(new Trophy(animal, place, date));
        }
        public int CountMaleLions()
        {
            int c = 0;
            foreach (Trophy e in Trophies)
            {
                if (e.animal.IsLion() && e.animal.Male) ++c;
            }
            return c;
        }
        public bool MaxHornWeigthRate(out double rate)
        {
            bool l = false;
            rate = 0.0;
            foreach (Trophy e in Trophies)
            {
                if (!e.animal.IsRhino()) continue;
                Rhino rhino = (Rhino)e.animal;
                double r = rhino.Horn / rhino.Weight;
                if (!l)
                {
                    l = true;
                    rate = r;
                }
                else if (rate < r)
                {
                    rate = r;
                }
            }
            return l;
        }
        public bool SearchEqualTusks()
        {
            foreach(Trophy e in Trophies)
            {
                if (e.animal.IsElephant() && ((Elephant)e.animal).Lefttusk==((Elephant)e.animal).Righttusk) return true;
            }
            return false;
        }
    }
}
