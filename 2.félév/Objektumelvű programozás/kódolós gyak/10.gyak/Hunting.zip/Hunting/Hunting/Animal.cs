﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hunting
{
    class Animal
    {
        public double Weight { get; }
        public bool Male { get; }
        protected Animal(double weight, bool male) { Weight = weight; Male = male; }
        public virtual bool IsLion() { return false; }
        public virtual bool IsRhino() { return false; }
        public virtual bool IsElephant() { return false; }
    }

    class Elephant : Animal
    {
        public double Lefttusk { get; }
        public double Righttusk { get; }
        public Elephant(double weight, double ltusk, double rtusk, bool male) : base(weight, male) 
        { Lefttusk = ltusk; Righttusk = rtusk; }
        public override bool IsElephant() { return true; }
    }
    class Rhino :  Animal
    {
        public double Horn { get; }
        public Rhino(double weight, double horn, bool male) : base(weight, male) 
        { Horn = horn; }
        public override bool IsRhino() { return true; }
    }
    class Lion : Animal 
    {
        public Lion(double weight, bool male) : base(weight, male) 
        {  }
        public override bool IsLion() { return true; }
    }

}
