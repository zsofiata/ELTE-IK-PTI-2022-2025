﻿namespace CarAlarm
{
    class Door 
    {
        public enum DoorState { closed, opened };
        public DoorState CurrentState { get; private set; }
        private AlarmSet alarmset;
        public Door() 
        {
            CurrentState = DoorState.closed;
        }

        public void Control(AlarmSet alarmset) 
        {  
            this.alarmset =  alarmset; 
        }

        public void Open()
        {
            if (CurrentState == DoorState.closed)
            {
                CurrentState = DoorState.opened;
                alarmset.Send(Signal.opened);
            }
        }
        public void Close()
        {
            CurrentState = DoorState.closed;
        }
    }
}
