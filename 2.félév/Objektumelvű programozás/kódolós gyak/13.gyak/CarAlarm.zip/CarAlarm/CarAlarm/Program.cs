﻿using System;
using System.Threading;

namespace CarAlarm
{
    class Program
    {
        static void Main()
        {
            System system = new(3);         Thread.Sleep(500); Console.WriteLine(system);

            system.controller.TurnOn();     Thread.Sleep(500); Console.WriteLine(system);
            system.doors[0].Open();         Thread.Sleep(500); Console.WriteLine(system);
            system.controller.TurnOff();    Thread.Sleep(500); Console.WriteLine(system);
            system.doors[0].Close();        Thread.Sleep(500); Console.WriteLine(system);
            system.controller.TurnOn();     Thread.Sleep(500); Console.WriteLine(system);
            system.Motion();                Thread.Sleep(500); Console.WriteLine(system);

            system.Stop();
        }
    }
}
