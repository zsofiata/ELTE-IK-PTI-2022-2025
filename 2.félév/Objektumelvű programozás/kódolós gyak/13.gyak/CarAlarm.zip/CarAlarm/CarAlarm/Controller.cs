﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarAlarm
{
    class Controller
    {
        private AlarmSet alarmSet;
        public void Control(AlarmSet alarmSet) { this.alarmSet = alarmSet; }
        public void TurnOn()
        {
            alarmSet.Send(Signal.on);
        }
        public void TurnOff()
        {
            alarmSet.Send(Signal.off);
        }
    }
}
