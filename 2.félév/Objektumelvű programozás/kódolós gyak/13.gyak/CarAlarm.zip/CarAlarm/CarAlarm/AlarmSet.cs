﻿namespace CarAlarm
{
    class AlarmSet : StateMachine.StateMachine<Signal>
    {
        private AlarmState currentState;
        
        public Door[] doors;
        private Sensor sensor;
        public AlarmSet() : base(Signal.none, Signal.final) 
        {
            currentState = Passive.Instance(this);
            Start();
        }
        public bool AllDoorsClosed()
        {
            foreach (Door d in doors)
            {
                if (d.CurrentState == Door.DoorState.opened) return false;
            }
            return true;
        }
        public void ActivateSensor()
        {
            sensor.Send(Signal.activate);
        }
        public void DeactivateSensor()
        {
            sensor.Send(Signal.deactivate);
        }
        public void Control(Sensor sensor, Door[] doors) 
        { 
            this.sensor = sensor; 
            this.doors = doors; 
        }

        protected override void Transition(Signal signal)
        {
            currentState = currentState.Transition(signal);
        }

        public override string ToString()
        {
            string msg = "alarmset is ";
            if (currentState == Passive.Instance(this)) msg += "passive,";
            else if (currentState == Active.Instance(this)) msg += "active,";
            else if (currentState == Alert.Instance(this)) msg += "alert,";
            return msg;
        }
    }

    abstract class AlarmState
    {
        protected AlarmSet alarmset;
        protected AlarmState(AlarmSet e) { alarmset = e; }
        public virtual AlarmState Transition(Signal signal) { return this; }
    }

    class Passive : AlarmState 
    {
        private static Passive instance = null;
        private Passive(AlarmSet s) : base(s) { }

        public static Passive Instance(AlarmSet s)
        {
            instance ??= new Passive(s);
            return instance;
        }

        public override AlarmState Transition(Signal signal)
        {
            if (signal == Signal.on && alarmset.AllDoorsClosed())
            {
                alarmset.ActivateSensor();
                return Active.Instance(alarmset);
            }
            else return this;
        }

    }

    class Active : AlarmState
    {
        private static Active instance = null;
        private Active(AlarmSet s) : base(s) { }

        public static Active Instance(AlarmSet s)
        {
            instance ??= new Active(s);
            return instance;
        }

        public override AlarmState Transition(Signal signal)
        {
            switch (signal)
            {
                case Signal.off:
                    alarmset.DeactivateSensor(); 
                    return Passive.Instance(alarmset);
                case Signal.opened:
                case Signal.motion:
                    return Alert.Instance(alarmset);
                default: return this;
            }
        }
    }

    class Alert : AlarmState
    {
        private static Alert instance = null;
        private Alert(AlarmSet s) : base(s) { }

        public static Alert Instance(AlarmSet s)
        {
            instance ??= new Alert(s);
            return instance;
        }

        public override AlarmState Transition(Signal signal)
        {
            if (signal == Signal.off)
            {
                alarmset.DeactivateSensor();
                return Passive.Instance(alarmset);
            }
            else return this;
        }
    }
}
