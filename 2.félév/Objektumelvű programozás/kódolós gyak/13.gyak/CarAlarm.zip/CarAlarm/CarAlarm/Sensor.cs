﻿namespace CarAlarm
{
    class Sensor : StateMachine.StateMachine<Signal>
    {
        private SensorState currentState;

        public AlarmSet Alarmset { get; private set; }

        public Sensor() : base(Signal.none, Signal.final)
        {
            currentState = Asleep.Instance(this);
            Start();
        }

        public void Control(AlarmSet alarmset) 
        { 
            Alarmset = alarmset; 
        }

        protected override void Transition(Signal signal)
        {
            currentState = currentState.Transition(signal);
        }
        public override string ToString()
        {
            string msg = "sensor is ";
            if (currentState == Awake.Instance(this)) msg += "awake";
            else if (currentState == Asleep.Instance(this)) msg += "asleep";
            return msg;
        }
    }

    abstract class SensorState
    {
        protected Sensor sensor;
        protected SensorState(Sensor e) { sensor = e; }
        public virtual SensorState Transition(Signal signal) 
        { 
            return this; 
        }
    }

    class Asleep : SensorState
    {
        private static Asleep instance = null;
        private Asleep(Sensor s) : base(s) { }

        public static Asleep Instance(Sensor s)
        {
            instance ??= new Asleep(s);
            return instance;
        }

        public override SensorState Transition(Signal signal)
        {
            if (signal == Signal.activate) return Awake.Instance(sensor);
            else return this;
        }
    }

    class Awake : SensorState
    {
        private static Awake instance = null;
        private Awake(Sensor s) : base(s) { }

        public static Awake Instance(Sensor s)
        {
            instance ??= new Awake(s);
            return instance;
        }

        public override SensorState Transition(Signal signal)
        {
            if (signal == Signal.deactivate) return Asleep.Instance(sensor);
            else if (signal == Signal.motion)
            {
                sensor.Alarmset.Send(Signal.motion);
                return this;
            }
            else return this;
        }
    }
}
