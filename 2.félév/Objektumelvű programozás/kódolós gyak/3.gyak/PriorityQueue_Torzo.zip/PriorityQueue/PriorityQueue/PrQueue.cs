﻿namespace PriorityQueue
{
    public class Element
    {
        public int pr;
        public string data;

        public Element() { data = ""; }
        public Element(int p, string str)
        {
            pr = p;
            data = str;
        }

        public override string ToString()
        {
            return "(" + pr.ToString() + ", " + "data" + ")";
        }

        public void Read()
        {
            Console.WriteLine("Elembe kerülő adat: ");
            data = Console.ReadLine()!;
            bool ok;
            do
            {
                Console.WriteLine("Elem prioritása (egész szám): ");
                try
                {
                    pr = int.Parse(Console.ReadLine()!);
                    ok = true;
                }
                catch (System.FormatException)
                {
                    ok = false;
                }
            } while (!ok);
        }
    }
    public class PrQueue
    {
        private readonly List<Element> seq = new();  //tároló sorozat vectorral implementálva
        public class PrQueueEmpty : Exception { }

    }
}

