using PriorityQueue;

namespace TestPriorityQueue
{
    [TestClass]
    public class UnitTestPriorityQueue
    {
        [TestMethod]
        public void TestAdd()
        {

        }

        [TestMethod]
        public void TestRemMax()
        {

        }

        [TestMethod]
        public void TestMaxIndex()
        {

        }
    }
}