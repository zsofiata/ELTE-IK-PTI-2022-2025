using PriorityQueue;

namespace TestPriorityQueue
{
    [TestClass]
    public class UnitTestPriorityQueue
    {
        [TestMethod]
        public void TestAdd()
        {
            PrQueue pq = new PrQueue();
            Element e = new Element();
            e.pr = 10;
            e.data = "10 pr elem";
            pq.Add(e);

            Assert.AreEqual(e,pq.GetMax());

            Element ee = new Element();
            ee.pr = 20;
            ee.data = "20 pr elem";
            pq.Add(ee);

            Assert.AreEqual(ee, pq.GetMax());

            Assert.AreEqual(2,pq.GetCount());
        }

        [TestMethod]
        public void TestRemMax()
        {
            PrQueue pq = new PrQueue();
            Element e = new Element();
            e.pr = 10;
            e.data = "10 pr elem";
            pq.Add(e);

            Element ee = new Element();
            ee.pr = 20;
            ee.data = "20 pr elem";
            pq.Add(ee);

            pq.RemMax();

            Assert.AreEqual(10, pq.GetMax().pr);
        }

        [TestMethod]
        public void TestMaxIndex()
        {
            PrQueue pq = new PrQueue();
            Element ee = new Element();
            ee.pr = 20;
            ee.data = "20 pr elem";
            pq.Add(ee);

            Element e = new Element();
            e.pr = 10;
            e.data = "10 pr elem";
            pq.Add(e);

            Assert.AreEqual(0,pq.MaxIndex());

        }
    }
}