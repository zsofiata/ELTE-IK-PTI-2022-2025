﻿namespace PriorityQueue
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Prioritasos sor");

            Menu test = new();
            test.Run();
        }
    }
}