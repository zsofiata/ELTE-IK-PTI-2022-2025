﻿
namespace Microwave
{
    class Door
    {
        private Magnetron magn;
        private Lamp lamp;
        public string CurrentState { get { return "door " + (Opened ? "is open" : "has been closed"); } }
        public void Control(Magnetron magn, Lamp lamp) { this.magn = magn; this.lamp = lamp; }
                public bool Opened { get; private set; }
        public void Open() { lamp.Send(Signal.open); magn.Send(Signal.open); Opened = true; }
        public void Close() { lamp.Send(Signal.close); Opened = false; }
    }
}
