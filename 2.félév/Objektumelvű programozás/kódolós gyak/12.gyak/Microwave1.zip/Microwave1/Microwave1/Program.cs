﻿
namespace Microwave
{
    class Program
    {
        static void Main()
        {
            MicroWave micro = new();micro.WriteState();

            micro.Door.Open();      micro.WriteState();
            micro.Door.Close();     micro.WriteState();
            micro.Button.Press();   micro.WriteState();
            micro.Button.Press();   micro.WriteState();
            micro.Door.Open();      micro.WriteState();
        }
    }
}
