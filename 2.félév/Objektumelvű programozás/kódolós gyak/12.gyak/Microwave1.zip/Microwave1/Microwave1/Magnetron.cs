﻿
namespace Microwave
{
    class Magnetron
    {
        private Door door;
        private Lamp lamp;
        private bool working;
        public Magnetron()
        {
            working = false;
        }
        public void Control(Lamp lamp)
        {
            this.lamp = lamp;
        }
        public void Check(Door door)
        {
            this.door = door;
        }
        public string CurrentState { get { return "magnetron " + (working ? "is working" : "is not working"); } }

        public void Send(Signal signal) // küldhetné egy eseménysorba, amiből az alábbi módon dolgozzuk fel)
        {
            if(signal == Signal.press)
            {
                if (!working && !door.Opened) Start();
                else if (working) Stop();
            }
        }
        void Start() { lamp.Send(Signal.start); working = true; }
        void Stop() { lamp.Send(Signal.stop); working = false; }
    }
}
