﻿
namespace Microwave
{
    class Lamp
    {
        private bool light_is_on;
        public string CurrentState { get { return "lamp " + (light_is_on ? "is lighting" : "is not lighting"); } }
        public void Send(Signal signal) // küldhetné egy eseménysorba, amiből az alábbi módon dolgozzuk fel)
        {
            switch (signal)
            {
                case Signal.open: case Signal.start: SwitchOn(); break;
                case Signal.close: case Signal.stop: SwitchOff(); break;
            }
        }
        void SwitchOn() { light_is_on = true; }
        void SwitchOff() { light_is_on = false; }
    }
}
