﻿using System;

namespace Microwave
{
    enum Signal { start, stop, press, open, close };
    class MicroWave
    {
        public Button Button { get; } = new();
        public Door Door { get; } = new();
        private Magnetron Magnetron { get; } = new();
        private Lamp Lamp { get; } = new();
        public MicroWave()
        {
            Button.Control(Magnetron);
            Door.Control(Magnetron, Lamp);
            Magnetron.Control(Lamp);
            Magnetron.Check(Door);
        }

        public void WriteState()
        {
            Console.WriteLine($"{Magnetron.CurrentState,-25}, {Lamp.CurrentState,-20}, {Door.CurrentState,-25}");
        }
    }
}
