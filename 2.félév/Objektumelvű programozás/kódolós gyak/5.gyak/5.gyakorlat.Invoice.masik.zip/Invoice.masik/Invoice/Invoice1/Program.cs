﻿using TextFile;

namespace Invoice1
{
    internal class Program
    {
        static void Main()
        {
            try
            {
                TextFileReader reader = new("input.txt");

                int income = 0;
                while (Invoice.Read(reader, out Invoice invoice))
                {
                    income += invoice.Sum;  // instead of income += invoice.Sum();
                }
                Console.WriteLine("Total income: {0}", income);
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("Input file does not exist");
            }
        }
    }
}