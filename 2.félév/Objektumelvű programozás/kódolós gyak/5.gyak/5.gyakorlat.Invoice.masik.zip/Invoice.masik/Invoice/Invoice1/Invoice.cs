﻿using TextFile;

namespace Invoice1
{
    class Invoice
    {
        public struct Product
        {
            public string id;
            public int price;
            public Product(string i, int p)
            { id = i; price = p; }
        }
        private readonly string name;
        private readonly List<Product> list = new();    
        public int Sum { get; private set; }

        public Invoice(string n)
        {
            name = n;
            Sum = 0;
        }
        public void Add(Product product)
        {
            list.Add(product);
            Sum += product.price;
        }

        /*                                      in the 1st version:
        public int Sum()
        {
            int total = 0;
            foreach (Product p in list)
            {
                total += p.price;
            }
            return total;
        }
        */

        public static bool Read(TextFileReader f, out Invoice invoice)
        {
            invoice = null;
            bool l = f.ReadLine(out string line);
            if (l)
            {
                char[] separators = new char[] { ' ', '\t' };
                string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                invoice = new Invoice(tokens[0]);
                for (int i = 1; i < tokens.Length; i += 2)
                {
                    invoice.Add(new Product(tokens[i], int.Parse(tokens[i + 1])));
                }
            }
            return l;
        }
    }
}
