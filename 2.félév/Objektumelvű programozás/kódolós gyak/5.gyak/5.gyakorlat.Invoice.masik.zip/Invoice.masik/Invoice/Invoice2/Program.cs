﻿using TextFile;

namespace Invoice2
{
    class Program
    {
        static void Main()
        {
            try
            {
                InFile f = new("input.txt");

                int income = 0;
                Invoice invoice;
                while ((invoice = f.Read()) != null)
                {
                    income += invoice.Sum;
                }
                Console.WriteLine("Total income: {0}", income);
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("Input file does not exist");
            }
        }
    }
}