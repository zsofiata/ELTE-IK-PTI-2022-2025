﻿#nullable disable

using TextFile;

namespace Invoice2
{
    class InFile
    {
        private readonly TextFileReader reader;

        public InFile(string fname)
        {
            reader = new TextFileReader(fname);
        }
        public Invoice Read()
        {
            Invoice invoice = null;
            bool l = reader.ReadLine(out string line);
            if (l)
            {
                char[] separators = new char[] { ' ', '\t' };
                string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                invoice = new Invoice(tokens[0]);
                for (int i = 1; i < tokens.Length; i += 2)
                {
                    invoice.Add(new Invoice.Product(tokens[i], int.Parse(tokens[i + 1])));
                }
            }
            return invoice;
        }
    }
}
