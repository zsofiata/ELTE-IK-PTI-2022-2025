﻿namespace Invoice2
{
    class Invoice
    {
        public struct Product
        {
            public string id;
            public int price;
            public Product(string i, int p)
            { id = i; price = p; }
        }
        private readonly string name;
        private readonly List<Product> list = new();    
        public int Sum { get; private set; }

        public Invoice(string n)
        {
            name = n;
            Sum = 0;
        }
        public void Add(Product product)
        {
            list.Add(product);
            Sum += product.price;
        }
    }
}
