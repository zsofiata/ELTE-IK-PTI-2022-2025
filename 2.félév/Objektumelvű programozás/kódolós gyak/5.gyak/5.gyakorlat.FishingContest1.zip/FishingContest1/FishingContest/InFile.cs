﻿using System;
using TextFile;
using static FishingContest.Fisher;

namespace FishingContest
{
    class InFile
    {
        private readonly TextFileReader reader;

        public InFile(string fname)
        {
            reader = new TextFileReader(fname);
        }

        public Fisher Read()
        {
            Fisher fisher = null;
            if (reader.ReadLine(out string line))
            {
                char[] separators = new char[] { ' ', '\t' };
                string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                fisher = new Fisher(tokens[0]);
                for (int i = 1; i < tokens.Length; i += 4)
                {
                    fisher.Add(new Catch(tokens[i], tokens[i + 1], double.Parse(tokens[i + 2]), double.Parse(tokens[i + 3])));
                }
            }
            return fisher;
        }

    }
}
