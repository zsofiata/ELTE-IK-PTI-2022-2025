﻿using System.Collections.Generic;

namespace FishingContest
{
    public class Fisher
    {
        public class Catch
        {
            public string datetime;
            public string species;
            public double length;
            public double weight;
            public Catch(string datetime, string species, double length, double weight)
            {
                this.datetime = datetime; this.species = species; this.length = length; this.weight = weight;
            }
        }

        public readonly string name;
        private readonly List<Catch> list = new();  // this list is not required
        public double Sum { get; private set; }
        public Fisher(string n)
        {
            name = n;
            Sum = 0.0;
        }
        public void Add(Catch catching)
        {
            list.Add(catching);
            if (catching.species == "ponty" && catching.length >= 0.5) Sum += catching.weight;   
        }
    }
}
