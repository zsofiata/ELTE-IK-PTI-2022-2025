﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FishingContest
{
    public class Fisher
    {
        public readonly string name;
        public readonly bool ok;
        public Fisher(string n, bool o)
        {
            name = n;
            ok = o;
        }

    }
}
