﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;

namespace FishingContest
{
    public class Program
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            try
            {
                Console.WriteLine("Ügyes horgászok:");
                foreach (string e in Collect(new Infile("input1.txt")))
                {
                    Console.WriteLine(e);
                }
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("Input file does not exist");
            }
        }
        public static List<string> Collect(Infile f)
        {
            List<string> names = new();
            Fisher fisher;
            while ( (fisher=f.Read())!=null )
            {
                if (fisher.ok) names.Add(fisher.name);
            }
            return names;
        }
    }
}
