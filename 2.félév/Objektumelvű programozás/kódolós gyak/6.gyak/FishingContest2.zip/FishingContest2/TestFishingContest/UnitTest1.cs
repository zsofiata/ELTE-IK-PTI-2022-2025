using Microsoft.VisualStudio.TestTools.UnitTesting;
using FishingContest;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;

namespace TestFishingContest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestOK0()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            string[] tokens = new string[] { "J�zsi" };
            Assert.AreEqual(false, Infile.OK(tokens));
        }

        [TestMethod]
        public void TestOK1()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            string[] tokens = new string[] { "J�zsi",   "09:55", "harcsa",  "11.1", "1.3",
                                                        "09:55", "harcsa",  "11.1", "1.2"  };
            Assert.AreEqual(false, Infile.OK(tokens));
        }

        [TestMethod]
        public void TestOK2()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            string[] tokens = new string[] { "J�zsi",   "09:55", "ponty",   "1.5", "0.5",
                                                        "09:55", "harcsa",  "6.1", "2.1",
                                                        "09:55", "harcsa",  "5.1", "2.0",
                                                        "09:55", "harcsa",  "4.1", "2.0",
                                                        "09:55", "harcsa",  "3.1", "2.0"
            };
            Assert.AreEqual(true, Infile.OK(tokens));
        }

        [TestMethod]
        public void TestOK3()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            string[] tokens = new string[] { "J�zsi",   "09:55", "ponty",   "0.5", "0.5",
                                                        "09:55", "harcsa",  "1.1", "1.0"  };
            Assert.AreEqual(false, Infile.OK(tokens));
        }
    }
}
