#include "sort.h"

void sort(size_t lines_size, Line *lines) {
    for (size_t i = 0; i < lines_size; ++i) {
        for (size_t j = i + 1; j < lines_size; ++j) {
            if (lines[i].count < lines[j].count) {
                Line tmp = lines[i];
                lines[i] = lines[j];
                lines[j] = tmp;
            }
        }
    }
}
