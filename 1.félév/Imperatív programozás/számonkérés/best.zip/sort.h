#pragma once

#include <stdlib.h>

#include "line.h"

void sort(size_t lines_size, Line *lines);
