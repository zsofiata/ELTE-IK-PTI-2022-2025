#pragma once

typedef struct Line {
    char *line;
    unsigned count; 
} Line;
