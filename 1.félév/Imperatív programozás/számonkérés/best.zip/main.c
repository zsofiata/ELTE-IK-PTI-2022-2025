#include <stdio.h>
#include <stdlib.h>

#include "file.h"

int main(int argc, char **argv) {
    if (argc < 2) {
        process_file(stdin);
        return 0;
    }

    for (size_t i = 0; i < (size_t)argc - 1; ++i) {
        char *path = argv[i + 1];
        FILE *file = fopen(path, "r");

        if (file == NULL) {
            fprintf(stderr, "ERROR: Could not open file: %s\n", path);
            continue;
        }

        if (!process_file(file)) {
            fprintf(stderr, "ERROR: Failed to process file: %s\n", path);
        }

        fclose(file);
    }
}
