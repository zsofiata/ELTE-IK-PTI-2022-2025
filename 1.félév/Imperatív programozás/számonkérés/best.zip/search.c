#include "search.h"

#include <stdlib.h>
#include <ctype.h>

ssize_t search_lines(size_t lines_size, const Line *lines, const char *line) {
    for (size_t i = 0; i < lines_size; ++i) {
        bool wrong = false;
        for (size_t j = 0; line[j] != '\0'; ++j) {
            if (tolower(lines[i].line[j]) != tolower(line[j])) {
                wrong = true;
                break;
            }
        }

        if (wrong == false) {
            return i;
        }
    }

    return -1;
}
