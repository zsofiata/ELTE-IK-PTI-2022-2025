#pragma once

#include <stdbool.h>
#include <stdlib.h>

#include "line.h"

ssize_t search_lines(size_t lines_size, const Line *lines, const char *line);
