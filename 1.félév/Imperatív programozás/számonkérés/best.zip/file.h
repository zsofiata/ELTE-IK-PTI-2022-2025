#pragma once

#include <stdbool.h>
#include <stdio.h>

bool process_file(FILE *file);
