#include "file.h"

#include <stdio.h>
#include <stdlib.h>

#include "line.h"
#include "search.h" 
#include "sort.h"

bool process_file(FILE *file) {
    size_t lines_capacity = 4;
    Line *lines = malloc(lines_capacity * sizeof(Line));
    size_t lines_size = 0;

    if (lines == NULL) {
        return false;
    }

    ssize_t length;
    char *line = NULL;
    size_t size;

    while ((length = getline(&line, &size, file)) != -1) {
        int lines_index = search_lines(lines_size, lines, line);
        
        if (lines_index != -1) {
            ++lines[lines_index].count;
            free(line);
            line = NULL;
            continue;
        }
        
        if (lines_size + 1 > lines_capacity) {
            lines_capacity *= 2;
            Line *new_lines = realloc(lines, lines_capacity * sizeof(Line));
        
            if (new_lines == NULL) {
                for (size_t i = 0; i < lines_size; ++i) {
                    free(lines[i].line);
                }

                free(lines);
                free(line);

                return false;
            }
        
            lines = new_lines;
        }
        
        size_t new_index = lines_size++;
        lines[new_index].line = line;
        lines[new_index].count = 1;
        
        line = NULL;
    }

    free(line);

    sort(lines_size, lines);

    for (size_t i = 0; i < lines_size; ++i) {
        printf("%d %s", lines[i].count, lines[i].line);
        free(lines[i].line);
    }

    free(lines);

    return true;
}
