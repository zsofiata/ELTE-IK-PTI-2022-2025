#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct lines 
    {
        char *line;
        int times;
    } lines;

void fail (void * prt)
{
    if (ptr == NULL)
    {
        exit (1);
    }
}

int main (int argc, char * argv[])
{   

    char c;

    FILE * file_ptr;
    file_prt = fopen(argv[1] ,"r");
    fail (file_ptr);

    lines ** array = (lines *)malloc (4 * sizeof (array));
    fail (array);
    

    int all = 4;
    int acc = 0;

            array[acc].line=malloc(1024));
        
            c = fgetc(file_ptr);
            while ( c != EOF)
            {
                ungets (c, file_ptr);
                fgets (array[acc].line,1024, file_ptr);

                array[acc].line[strcspn(array[acc].line,"\n")] = '\0';
                //array[acc].times = (array[acc].line);
            // file_ptr = strlen(file_ptr);

                if ((acc+1) == all)
                {
                    all *= 2;
                    array = realloc (lines, (all) * (sizeof(array)));

                    strcpy(text[acc],l.lines);

                    c = fgetc(l.line);
                    acc++;
                
                free(text);
        }
        fclose (file_ptr);

    return 0;
}